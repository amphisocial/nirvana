# Nirvana retirement accounts + AI planner UI v1

This overlay adds:

- IRA / Roth IRA as an explicit asset type
- 401(k) / 403(b) as an explicit asset type
- Growth, balanced, conservative, and self-managed investment profiles
- Per-account expected return and volatility assumptions
- Balance-weighted retirement projection return and volatility
- Investment profile display on saved account rows
- Persistent Boldin-inspired Nirvana AI planner drawer
- Cleaner teal/green financial-planning visual system
- Existing edit/delete support retained

## Install

```bash
cd /tmp
unzip nirvana-retirement-accounts-ai-ui-v1-overlay.zip

sudo cp -a \
  /opt/apps/nirvana \
  /opt/apps/nirvana-backup-before-retirement-accounts-ui

sudo rsync -av \
  --exclude INSTALL.md \
  nirvana-retirement-accounts-ai-ui-v1-overlay/ \
  /opt/apps/nirvana/

sudo chown -R ubuntu:ubuntu /opt/apps/nirvana
cd /opt/apps/nirvana

node --check server/routes/accounts.js
node --check server/routes/dashboard.js
node --check server/routes/retirement.js
node --check public/app.js

npm run db:migrate

pm2 restart nirvana --update-env
pm2 save
pm2 logs nirvana --lines 80
```

No `npm install` or `npm ci` is required.

After restart, hard-refresh Chrome with `Command + Shift + R`.

## Growth assumptions

Defaults are intentionally configurable assumptions:

- Growth funds: 8.0% expected return, 18.0% volatility
- Balanced funds: 6.0% expected return, 12.0% volatility
- Lower-risk funds: 4.0% expected return, 7.0% volatility
- Self-managed stocks: 7.0% expected return, 20.0% volatility

Users may edit these values. Nirvana treats them as planning assumptions, not predictions.
