import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { projectRetirement } from '../services/financial-engine.js';

export const retirementRouter = Router();

const planSchema = z.object({
  currentAge: z.coerce.number().int().min(18).max(90),
  retirementAge: z.coerce.number().int().min(19).max(95),
  planEndAge: z.coerce.number().int().min(50).max(120),
  annualContribution: z.coerce.number().min(0),
  annualRetirementSpending: z.coerce.number().min(0),
  expectedReturn: z.coerce.number().min(-0.5).max(0.5),
  volatility: z.coerce.number().min(0).max(1),
  inflation: z.coerce.number().min(-0.02).max(0.2)
}).refine((value) => value.retirementAge > value.currentAge, { message: 'Retirement age must exceed current age' })
  .refine((value) => value.planEndAge > value.retirementAge, { message: 'Plan end age must exceed retirement age' });

retirementRouter.get('/projection', async (req, res, next) => {
  try {
    const [planResult, portfolioResult] = await Promise.all([
      pool.query('SELECT * FROM retirement_plans WHERE household_id = $1', [req.householdId]),
      pool.query(`
        SELECT account_type,
               current_balance::float8 AS current_balance,
               expected_return::float8 AS expected_return,
               expected_volatility::float8 AS expected_volatility,
               investment_style
        FROM accounts
        WHERE household_id = $1
          AND account_type IN ('cash', 'brokerage', 'ira', '401k', 'retirement', 'hsa', '529')`,
      [req.householdId])
    ]);
    const plan = planResult.rows[0];
    if (!plan) return res.status(404).json({ error: 'Retirement plan not found' });
    const defaultReturns = {
      cash: 0.02,
      brokerage: 0.07,
      ira: 0.06,
      '401k': 0.06,
      retirement: 0.06,
      hsa: 0.06,
      '529': 0.055
    };
    const defaultVolatility = {
      cash: 0.01,
      brokerage: 0.17,
      ira: 0.12,
      '401k': 0.12,
      retirement: 0.12,
      hsa: 0.12,
      '529': 0.11
    };
    const portfolioRows = portfolioResult.rows;
    const startingPortfolio = portfolioRows.reduce(
      (sum, row) => sum + Number(row.current_balance || 0), 0
    );
    const weightedReturn = startingPortfolio > 0
      ? portfolioRows.reduce(
          (sum, row) => sum + Number(row.current_balance || 0) *
            Number(row.expected_return ?? defaultReturns[row.account_type] ?? plan.expected_return),
          0
        ) / startingPortfolio
      : Number(plan.expected_return);
    const weightedVolatility = startingPortfolio > 0
      ? portfolioRows.reduce(
          (sum, row) => sum + Number(row.current_balance || 0) *
            Number(row.expected_volatility ?? defaultVolatility[row.account_type] ?? plan.volatility),
          0
        ) / startingPortfolio
      : Number(plan.volatility);

    const projection = projectRetirement({
      currentAge: plan.current_age,
      retirementAge: plan.retirement_age,
      endAge: plan.plan_end_age,
      startingPortfolio,
      annualContribution: plan.annual_contribution,
      annualRetirementSpending: plan.annual_retirement_spending,
      expectedReturn: weightedReturn,
      volatility: weightedVolatility,
      inflation: plan.inflation,
      simulationCount: 1000
    });
    projection.accountGrowthModel = {
      weightedExpectedReturn: weightedReturn,
      weightedVolatility,
      source: portfolioRows.length
        ? 'Balance-weighted account investment profiles'
        : 'Retirement plan default',
      accounts: portfolioRows.map((row) => ({
        accountType: row.account_type,
        balance: Number(row.current_balance || 0),
        investmentStyle: row.investment_style,
        expectedReturn: Number(row.expected_return ?? defaultReturns[row.account_type] ?? plan.expected_return),
        expectedVolatility: Number(row.expected_volatility ?? defaultVolatility[row.account_type] ?? plan.volatility)
      }))
    };
    res.json(projection);
  } catch (error) { next(error); }
});

retirementRouter.put('/plan', async (req, res, next) => {
  try {
    const value = planSchema.parse(req.body);
    const result = await pool.query(`
      INSERT INTO retirement_plans
        (household_id, current_age, retirement_age, plan_end_age, annual_contribution, annual_retirement_spending, expected_return, volatility, inflation, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,now())
      ON CONFLICT (household_id) DO UPDATE SET
        current_age = EXCLUDED.current_age,
        retirement_age = EXCLUDED.retirement_age,
        plan_end_age = EXCLUDED.plan_end_age,
        annual_contribution = EXCLUDED.annual_contribution,
        annual_retirement_spending = EXCLUDED.annual_retirement_spending,
        expected_return = EXCLUDED.expected_return,
        volatility = EXCLUDED.volatility,
        inflation = EXCLUDED.inflation,
        updated_at = now()
      RETURNING *`,
      [req.householdId, value.currentAge, value.retirementAge, value.planEndAge, value.annualContribution,
        value.annualRetirementSpending, value.expectedReturn, value.volatility, value.inflation]
    );
    res.json(result.rows[0]);
  } catch (error) { next(error); }
});
